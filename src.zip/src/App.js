// import DataTable from './DataTable';
import Form from './Form';


function App() {
  return (
    <>
     {/* <Form /> */}
     <DataTable />
    </>
  );
}

export default App;
